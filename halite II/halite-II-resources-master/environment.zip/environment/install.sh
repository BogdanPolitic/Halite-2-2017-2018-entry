#!/usr/bin/env bash

set -e

cmake .
make
